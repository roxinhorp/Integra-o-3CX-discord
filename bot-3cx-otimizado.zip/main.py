
import os
import asyncio
import discord
from discord.ext import commands
from fastapi import FastAPI, Request, HTTPException, Query
from pydantic import BaseModel
import uvicorn
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

# --- Configuração do Bot Discord ---
INTENTS = discord.Intents.default()
INTENTS.message_content = True
INTENTS.members = True

bot = commands.Bot(command_prefix='!', intents=INTENTS)

# --- Configuração do Servidor Webhook (FastAPI) ---
app = FastAPI()

class WebhookData(BaseModel):
    extension: str
    caller_number: str
    duration: str
    call_id: str
    agent_name: str
    call_type: str

@bot.event
async def on_ready():
    print(f'✅ Bot logado como {bot.user}')
    print(f'🚀 Servidor Webhook rodando na porta {os.getenv("WEBHOOK_PORT", 5000)}')

@app.post("/webhook/3cx")
async def handle_3cx_webhook(
    data: WebhookData, 
    secret: str = Query(None)
):
    # Validar segredo
    expected_secret = os.getenv('WEBHOOK_SECRET')
    if secret != expected_secret:
        raise HTTPException(status_code=401, detail="Unauthorized")

    print(f"📞 Chamada recebida: {data.call_id} para o agente {data.agent_name}")

    # Tentar encontrar o usuário no Discord
    # Otimização: Tenta encontrar por nome de exibição ou nome de usuário
    target_user = None
    for guild in bot.guilds:
        # Tenta encontrar o membro pelo nome (display_name ou name)
        member = discord.utils.get(guild.members, display_name=data.agent_name) or \
                 discord.utils.get(guild.members, name=data.agent_name)
        
        if member:
            target_user = member
            break

    if target_user:
        # Criar um Embed elegante para a notificação
        embed = discord.Embed(
            title="📞 Nova Chamada Registrada",
            color=discord.Color.blue(),
            description=f"Detalhes da chamada recebida via 3CX."
        )
        embed.add_field(name="Tipo", value=data.call_type, inline=True)
        embed.add_field(name="Duração", value=data.duration, inline=True)
        embed.add_field(name="Número do Cliente", value=f"`{data.caller_number}`", inline=False)
        embed.add_field(name="Ramal", value=data.extension, inline=True)
        embed.add_field(name="ID da Chamada", value=data.call_id, inline=True)
        embed.set_footer(text="Sistema de Integração 3CX-Discord")

        try:
            await target_user.send(embed=embed)
            print(f'✅ DM enviada para {target_user.name}')
        except discord.Forbidden:
            print(f'❌ Erro: Não foi possível enviar DM para {target_user.name}. Verifique as permissões.')
    else:
        print(f'⚠️ Aviso: Agente "{data.agent_name}" não encontrado em nenhum servidor do bot.')

    return {"status": "success"}

# --- Execução Concorrente ---
async def run_bot():
    token = os.getenv('DISCORD_TOKEN')
    if not token:
        print("❌ Erro: DISCORD_TOKEN não encontrado no arquivo .env")
        return
    await bot.start(token)

async def run_server():
    port = int(os.getenv("WEBHOOK_PORT", 5000))
    config = uvicorn.Config(app, host="0.0.0.0", port=port, log_level="info")
    server = uvicorn.Server(config)
    await server.serve()

async def main():
    # Rodar bot e servidor simultaneamente
    await asyncio.gather(
        run_bot(),
        run_server()
    )

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 Bot desligado pelo usuário.")
